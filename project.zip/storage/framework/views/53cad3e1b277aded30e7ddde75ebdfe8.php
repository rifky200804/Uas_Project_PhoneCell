<?php $__env->startSection('title',config('app.name')." | User"); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded h-100 p-4">
            <h6>Data Product</h6>
            <a href="<?php echo e(route('product.create')); ?>">Create Product</a>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr style="text-align: center">
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Category</th>
                            <th scope="col">Brand</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;    
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="text-align: center">
                            <th scope="row"><?php echo e($no); ?></th>
                            <td><?php echo e($value->name); ?></td>
                            <td><?php echo e($value->name_category); ?></td>
                            <td><?php echo e($value->name_brand); ?></td>
                            <td>
                                <a href="<?php echo e(route('product.showAdmin',$value->id)); ?>" class="btn btn-info rounded-pill">Show</a>
                                <a href="<?php echo e(route('product.edit',$value->id)); ?>" class="btn btn-warning rounded-pill">Edit</a>
                                <a href="<?php echo e(route('product.destroy',$value->id)); ?>" class="btn btn-danger rounded-pill">Delete</a>
                            </td>
                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-6 d-flex justify-content-start">
                        Page <?php echo e($page); ?> from <?php echo e($totalPage); ?> With <?php echo e($totalData); ?> Data
                    </div>
                    <div class="col-md-6 d-flex justify-content-end">
                        <?php if($page != 1): ?>
                        <a href="<?php echo e(url('/admin/product?page=1')); ?>" class="btn btn-secondary" style="margin-right:5px";><<</a>
                        <a href="<?php echo e(url('/admin/product?page='.($page-1) )); ?>" class="btn btn-secondary" style="margin-right:5px";><</a>
                        <?php endif; ?>
                        <div class="btn-group me-2" role="group" aria-label="">
                            <?php
                                if($page > 5){
                                        $checkNumberPage = ceil($page / 5);
                                        $endPage = $checkNumberPage * 5;
                                        $startPage = $endPage - 4;
                                        $number = $startPage;
                                        if($totalPage < $endPage){
                                            $max = $totalPage;
                                        }else{
                                            $max = $endPage;    
                                        }
                                    
                                }else{
                                    $number = 1;
                                    $max = 5; 
                                    if($max > $totalPage){
                                        $max = $totalPage;
                                    }
                                }
                            ?>
                            <?php for($i = $number;$i <= $max;$i++): ?>
                            
                            <a href="<?php echo e(url('/admin/product?page='.$i)); ?>" class="btn  <?php if($i == $page): ?> btn-primary <?php else: ?> btn-secondary <?php endif; ?>"><?php echo e($i); ?></a>

                            <?php endfor; ?>
                            <?php if($page != $totalPage): ?>
                            <a href="<?php echo e(url('/admin/product?page='.($page+1) )); ?>" class="btn btn-secondary" style="margin-left:5px";>></a>
                            <a href="<?php echo e(url('/admin/product?page='.$totalPage)); ?>" class="btn btn-secondary" style="margin-left:5px";>>></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\uas\phoneCell\resources\views/admin/product/index.blade.php ENDPATH**/ ?>