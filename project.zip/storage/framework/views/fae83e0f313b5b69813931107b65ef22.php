<?php $__env->startSection('title',config('app.name')." | User"); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded h-100 p-4">
            <h6>Data Categories</h6>
            <a href="<?php echo e(route('category.create')); ?>">Create Category</a>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;    
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($no); ?></th>
                            <td><?php echo e($value->name); ?></td>
                            <td>
                                
                                
                                <a href="<?php echo e(route('category.destroy',$value->id)); ?>" class="btn btn-danger rounded-pill">Delete</a>
                            </td>
                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-md-6 d-flex justify-content-start">
                        Page <?php echo e($page); ?> from <?php echo e($totalPage); ?> With <?php echo e($totalData); ?> Data
                    </div>
                    <div class="col-md-6 d-flex justify-content-end">
                        <?php if($page != 1): ?>
                        <a href="<?php echo e(url('/admin/category?page=1')); ?>" class="btn btn-secondary" style="margin-right:5px";><<</a>
                        <a href="<?php echo e(url('/admin/category?page='.($page-1) )); ?>" class="btn btn-secondary" style="margin-right:5px";><</a>
                        <?php endif; ?>
                        <div class="btn-group me-2" role="group" aria-label="">
                            <?php
                                if($page > 5){
                                        $checkNumberPage = ceil($page / 5);
                                        $endPage = $checkNumberPage * 5;
                                        $startPage = $endPage - 4;
                                        $number = $startPage;
                                        if($totalPage < $endPage){
                                            $max = $totalPage;
                                        }else{
                                            $max = $endPage;    
                                        }
                                    
                                }else{
                                    $number = 1;
                                    $max = 5; 
                                    if($max > $totalPage){
                                        $max = $totalPage;
                                    }
                                }
                            ?>
                            <?php for($i = $number;$i <= $max;$i++): ?>
                            
                            <a href="<?php echo e(url('/admin/category?page='.$i)); ?>" class="btn  <?php if($i == $page): ?> btn-primary <?php else: ?> btn-secondary <?php endif; ?>"><?php echo e($i); ?></a>

                            <?php endfor; ?>
                            <?php if($page != $totalPage): ?>
                            <a href="<?php echo e(url('/admin/category?page='.($page+1) )); ?>" class="btn btn-secondary" style="margin-left:5px";>></a>
                            <a href="<?php echo e(url('/admin/category?page='.$totalPage)); ?>" class="btn btn-secondary" style="margin-left:5px";>>></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\uas\phoneCell\resources\views/admin/category/index.blade.php ENDPATH**/ ?>