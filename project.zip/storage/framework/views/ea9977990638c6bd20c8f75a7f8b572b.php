

<?php $__env->startSection('title',config('app.name'." | Shop")); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-12">
                <nav class="breadcrumb bg-light mb-30">
                    <a class="breadcrumb-item text-dark" href="<?php echo e(route('welcome')); ?>">Home</a>
                    <a class="breadcrumb-item text-dark" href="<?php echo e(route('shop.index')); ?>">Shop</a>
                    <span class="breadcrumb-item active"><?php echo e($data->name); ?></span>
                </nav>
            </div>
        </div>
    </div>

    <div class="container-fluid pb-5">
        <div class="row px-xl-5">
            <div class="col-lg-5 mb-30">
                <div id="product-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner bg-light">
                        <div class="carousel-item active">
                            <img class="w-100 h-100" src="<?php if(isset($value->foto)): ?> <?php echo e(asset('/images_product/'.$value->foto)); ?> <?php else: ?> <?php echo e(asset('logo.jpg')); ?> <?php endif; ?>" alt="Image">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#product-carousel" data-slide="prev">
                        <i class="fa fa-2x fa-angle-left text-dark"></i>
                    </a>
                    <a class="carousel-control-next" href="#product-carousel" data-slide="next">
                        <i class="fa fa-2x fa-angle-right text-dark"></i>
                    </a>
                </div>
            </div>

            <div class="col-lg-7 h-auto mb-30">
                <div class="h-100 bg-light p-30">
                    <h3><?php echo e($data->name); ?></h3>
                    <div class="d-flex mb-3">
                        
                    </div>
                    <h3 class="font-weight-semi-bold mb-4">Rp. <?php echo e(number_format($data->price,2,',','.')); ?></h3>
                    <p class="mb-4"><?php echo e($data->description); ?></p>
                    <div class="d-flex mb-3">
                        
                    </div>
                    <div class="d-flex mb-4">
                        
                    </div>
                    <div class="d-flex mb-4">
                        <strong class="text-dark mr-3"></strong>
                        <form action="<?php echo e(url('/cart/'.$data->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="d-flex align-items-center mb-4 pt-2">
                                <div class="input-group quantity mr-3" style="width: 130px;">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary btn-minus">
                                            <i class="fa fa-minus"></i>
                                        </button>
                                    </div>
                                    <input type="text" class="form-control bg-secondary border-0 text-center" value="1" name="quantity">
                                    <div class="input-group-btn">
                                        <button class="btn btn-primary btn-plus">
                                            <i class="fa fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary px-3"><i class="fa fa-shopping-cart mr-1"></i> Add To
                                    Cart</button>
                            </div>
                        </form>
                    </div>
                    <div class="d-flex pt-2">
                        <strong class="text-dark mr-2">Share on:</strong>
                        <div class="d-inline-flex">
                            <a class="text-dark px-2" href="">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a class="text-dark px-2" href="">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a class="text-dark px-2" href="">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a class="text-dark px-2" href="">
                                <i class="fab fa-pinterest"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\uas\phoneCell\resources\views/shop/show.blade.php ENDPATH**/ ?>