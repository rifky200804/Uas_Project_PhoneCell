

<?php $__env->startSection('title',config('app.name')); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid mb-3">
    <div class="row px-xl-5">
        <div class="col-lg-12">
            <div id="header-carousel" class="carousel slide carousel-fade mb-30 mb-lg-0" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#header-carousel" data-slide-to="0" class=""></li>
                    <li data-target="#header-carousel" data-slide-to="1" class="active"></li>
                    <li data-target="#header-carousel" data-slide-to="2" class=""></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item position-relative" style="height: 430px;">
                        <img class="position-absolute w-100 h-100" src="<?php echo e(asset('welcome/handphone1.jpeg')); ?>" style="object-fit: cover;">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 700px;">
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item position-relative active" style="height: 430px;">
                        <img class="position-absolute w-100 h-100" src="<?php echo e(asset('welcome/handphone2.jpeg')); ?>" style="object-fit: cover;">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 700px;">
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item position-relative" style="height: 430px;">
                        <img class="position-absolute w-100 h-100" src="<?php echo e(asset('welcome/handphone3.jpeg')); ?>" style="object-fit: cover;">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 700px;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid pt-5">
    <h2 class="section-title position-relative text-uppercase mx-xl-5 mb-4"><span class="bg-secondary pr-3">Categories</span></h2>
    <div class="row px-xl-5 pb-3">
        <?php $__currentLoopData = $categoryTotal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col-sm-6 pb-1">
            <a class="text-decoration-none" href="/shop?category=<?php echo e($item->name_category); ?>">
                <div class="cat-item d-flex align-items-center mb-4">
                    <div class="overflow-hidden" style="width: 100px; height: 100px;">
                        <img class="img-fluid" src="<?php if(isset($item->foto)): ?> <?php echo e(asset('/images_product/'.$item->foto)); ?> <?php else: ?> <?php echo e(asset('logo.jpg')); ?> <?php endif; ?>" alt="">
                    </div>
                    <div class="flex-fill pl-3">
                        <h6><?php echo e($item->name_category); ?></h6>
                        <small class="text-body"><?php echo e($item->total_product); ?> Products</small>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>



<div class="container-fluid pt-5 pb-3">
    <h2 class="section-title position-relative text-uppercase mx-xl-5 mb-4"><span class="bg-secondary pr-3">New Products</span></h2>
    <div class="row px-xl-5">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col-sm-6 pb-1">
            <div class="product-item bg-light mb-4">
                <div class="product-img position-relative overflow-hidden">
                    <img class="img-fluid w-100" src="<?php if(isset($value->foto)): ?> <?php echo e(asset('/images_product/'.$value->foto)); ?> <?php else: ?> <?php echo e(asset('logo.jpg')); ?> <?php endif; ?>" alt="" width="100px" height="100px">
                    <div class="product-action">
                        <form action="<?php echo e(url('/cart/'.$value->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="quantity" value="1">
                            <button type="submit" class="btn btn-outline-dark btn-square">
                                <i class="fa fa-shopping-cart"></i>
                            </button>
                        </form>
                        <a class="btn btn-outline-dark btn-square" href="<?php echo e(route('shop.show',$value->id)); ?>"><i class="fa fa-search"></i></a>
                    </div>
                </div>
                <div class="text-center py-4">
                    <a class="h6 text-decoration-none text-truncate" href=""><?php echo e($value->name); ?></a>
                    <div class="d-flex align-items-center justify-content-center mt-2">
                        <h5>Rp. <?php echo e(number_format($value->price,2,',','.')); ?></h5><h6 class="text-muted ml-2"></h6>
                    </div>
                    <div class="d-flex align-items-center justify-content-center mb-1">
                        
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\uas\phoneCell\resources\views/welcome.blade.php ENDPATH**/ ?>