

<?php $__env->startSection('title',config('app.name'). " | Order"); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="bg-light rounded h-100 p-4">
        <h6>Data Order <?php echo e((isset($_GET['status'])) ? $_GET['status'] : 'waiting for payment' ); ?></h6>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr style="text-align: center">
                        <th scope="col">#</th>
                        <th scope="col">Name Customer</th>
                        <th scope="col">totalPrice</th>
                        <th scope="col">totalItems</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;    
                        $status = [
                            'waiting for payment',
                            'packed',
                            'in delivery',
                            'finished'
                        ];
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="text-align: center">
                        <th scope="row"><?php echo e($no); ?></th>
                        <td><?php echo e($value->name_customer); ?></td>
                        <td><?php echo e($value->total_price); ?></td>
                        <td><?php echo e($value->total_product); ?></td>
                        <td>
                            <form action="<?php echo e(route('order.update')); ?>" method="post" >
                                <?php echo csrf_field(); ?>
                                
                                <input type="hidden" name="processCode" value="<?php echo e($value->processCode); ?>">
                                <?php if($value->status != 'finished'): ?>
                                    <?php $index = array_search($value->status, $status); ?>
                                    <button type="submit" name="status" value="<?php echo e($status[$index+1]); ?>" class="btn btn-primary">Process to <?php echo e($status[$index+1]); ?></button>  
                                <?php else: ?>
                                <?php echo e($value->status); ?>

                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                    <?php $no++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\uas\phoneCell\resources\views/admin/order/index.blade.php ENDPATH**/ ?>