

<?php $__env->startSection('title',config('app.name')." | Shop"); ?>
<?php $__env->startSection('content'); ?>

<?php if(isset($_GET['brand']) &&$_GET['brand']!= ''): ?>
    <?php
        // dd($dataBrand);
        $strBrand = implode(',',$checkedBrand);
    ?>
<?php endif; ?>
 <!-- Shop Start -->
 <div class="container-fluid">
    <div class="row px-xl-5">
        <!-- Shop Sidebar Start -->
        <div class="col-lg-3 col-md-4">
            <!-- Price Start -->
            <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Filter by price</span></h5>
            <div class="bg-light p-4 mb-30">
                <form method="GET">
                    <?php if(isset($_GET['categories']) && $_GET['categories'] != ""): ?>
                        <input type="hidden" name="categories" value="<?php echo e($_GET['categories']); ?>">
                    <?php endif; ?>
                    <?php if(isset($_GET['brand']) && $_GET['brand'] != ""): ?>
                        <input type="hidden" name="brand" value="<?php echo e($strBrand); ?>">
                    <?php endif; ?>
                    <div class="custom-control custom-radio d-flex align-items-center justify-content-between mb-3">
                        <input type="radio" name="price" value="0-1jt" class="custom-control-input" id="price-1" <?php if(isset($_GET['price']) && $_GET['price'] == '0-1jt'): ?> checked  <?php endif; ?>>
                        <label class="custom-control-label" for="price-1">Rp. 0 - Rp. 1.000.000,00</label>
                        <span class="badge border font-weight-normal">0-1jt</span>
                    </div>
                    <div class="custom-control custom-radio d-flex align-items-center justify-content-between mb-3">
                        <input type="radio" name="price" value="1jt-3jt" class="custom-control-input" id="price-2" <?php if(isset($_GET['price']) && $_GET['price'] == '1jt-3jt'): ?> checked  <?php endif; ?>>
                        <label class="custom-control-label" for="price-2">Rp. 1.000.000,00 - Rp. 3.000.000,00</label>
                        <span class="badge border font-weight-normal">1jt-3jt</span>
                    </div>
                    <div class="custom-control custom-radio d-flex align-items-center justify-content-between mb-3">
                        <input type="radio" name="price" value="3jt-5jt" class="custom-control-input" id="price-3" <?php if(isset($_GET['price']) && $_GET['price'] == '3jt-5jt'): ?> checked  <?php endif; ?>>
                        <label class="custom-control-label" for="price-3">Rp. 3.000.000,00 - Rp. 5.000.000,00</label>
                        <span class="badge border font-weight-normal">3jt-5jt</span>
                    </div>
                    <div class="custom-control custom-radio d-flex align-items-center justify-content-between mb-3">
                        <input type="radio" name="price" value="5jt-10jt" class="custom-control-input" id="price-4" <?php if(isset($_GET['price']) && $_GET['price'] == '5jt-10jt'): ?> checked  <?php endif; ?>>
                        <label class="custom-control-label" for="price-4">Rp. 5.000.000,00 - Rp. 10.000.000,00</label>
                        <span class="badge border font-weight-normal">5jt-10jt</span>
                    </div>
                    <div class="custom-control custom-radio d-flex align-items-center justify-content-between mb-3">
                        <input type="radio" name="price" value=">10jt" class="custom-control-input" id="price-5" <?php if(isset($_GET['price']) && $_GET['price'] == '>10jt'): ?> checked  <?php endif; ?>>
                        <label class="custom-control-label" for="price-5">> Rp.10.000.000,00</label>
                        <span class="badge border font-weight-normal">> 10jt</span>
                    </div>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </form>
            </div>
            <!-- Price End -->
            
            <!-- Color Start -->
            <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Filter by Brand</span></h5>
            <div class="bg-light p-4 mb-30">
                <form method="GET">
                    <?php if(isset($_GET['price']) && $_GET['price'] != ""): ?>
                        <input type="hidden" name="price" value="<?php echo e($_GET['price']); ?>">
                    <?php endif; ?>

                    <?php if(isset($_GET['categories']) && $_GET['categories'] != ""): ?>
                        <input type="hidden" name="categories" value="<?php echo e($_GET['categories']); ?>">
                    <?php endif; ?>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                        <input type="checkbox" class="custom-control-input" name="brand[]" <?php if(in_array($value->name,$checkedBrand)): ?> checked <?php endif; ?> value="<?php echo e($value->name); ?>" id="<?php echo e($value->name); ?>_<?php echo e($value->id); ?>">
                        <label class="custom-control-label" for="<?php echo e($value->name); ?>_<?php echo e($value->id); ?>"><?php echo e($value->name); ?></label>
                        <span class="badge border font-weight-normal"><?php echo e($value->name); ?></span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </form>
            </div>
            <!-- Color End -->

            <!-- Size Start -->

            <!-- Size End -->
        </div>
        <!-- Shop Sidebar End -->


        <!-- Shop Product Start -->
        <div class="col-lg-9 col-md-8">
            <div class="row pb-3">
                <div class="col-12 pb-1">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <div>
                            
                        </div>
                        <div class="ml-2">
                            <div class="btn-group ml-2">
                                <button type="button" class="btn btn-sm btn-light dropdown-toggle" data-toggle="dropdown">Showing</button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="<?php echo e(url('/shop?'."size=10")); ?> <?php if(isset($_GET['categories'])): ?> <?php echo e('&categories='.$_GET['categories']); ?> <?php endif; ?> <?php if(isset($_GET['brand'])): ?> <?php echo e('&brand='.$strBrand); ?> <?php endif; ?> <?php if(isset($_GET['price'])): ?> <?php echo e('&price='.$_GET['price']); ?> <?php endif; ?>">10</a>
                                    <a class="dropdown-item" href="<?php echo e(url('/shop?'."size=20")); ?> <?php if(isset($_GET['categories'])): ?> <?php echo e('&categories='.$_GET['categories']); ?> <?php endif; ?> <?php if(isset($_GET['brand'])): ?> <?php echo e('&brand='.$strBrand); ?> <?php endif; ?> <?php if(isset($_GET['price'])): ?> <?php echo e('&price='.$_GET['price']); ?> <?php endif; ?>">20</a>
                                    <a class="dropdown-item" href="<?php echo e(url('/shop?'."size=30")); ?> <?php if(isset($_GET['categories'])): ?> <?php echo e('&categories='.$_GET['categories']); ?> <?php endif; ?> <?php if(isset($_GET['brand'])): ?> <?php echo e('&brand='.$strBrand); ?> <?php endif; ?> <?php if(isset($_GET['price'])): ?> <?php echo e('&price='.$_GET['price']); ?> <?php endif; ?>">30</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                    <div class="product-item bg-light mb-4">
                        <div class="product-img position-relative overflow-hidden">
                            <img class="img-fluid w-100" src="<?php if(isset($value->foto)): ?> <?php echo e(asset('/images_product/'.$value->foto)); ?> <?php else: ?> <?php echo e(asset('logo.jpg')); ?> <?php endif; ?>" alt="">
                            <div class="product-action">
                                <form action="<?php echo e(url('/cart/'.$value->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="quantity" value="1">
                                    <button type="submit" class="btn btn-outline-dark btn-square">
                                        <i class="fa fa-shopping-cart"></i>
                                    </button>
                                </form>
                                    <a class="btn btn-outline-dark btn-square" href="<?php echo e(route('shop.show',$value->id)); ?>"><i class="fa fa-search"></i></a>
                            </div>
                        </div>
                        <div class="text-center py-4">
                            <a class="h6 text-decoration-none text-truncate" href=""><?php echo e($value->name); ?></a>
                            <div class="d-flex align-items-center justify-content-center mt-2">
                                <h5>Rp. <?php echo e(number_format($value->price,2,',','.')); ?></h5><h6 class="text-muted ml-2"><del></del></h6>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12">
                    <nav>
                      <ul class="pagination justify-content-center">
                        <li class="page-item <?php if($page == 1): ?> disabled <?php endif; ?>">
                            <a class="page-link" href="/shop?page=<?php echo e(($page-1)); ?> <?php if(isset($_GET['categories'])): ?> <?php echo e('&categories='.$_GET['categories']); ?> <?php endif; ?> <?php if(isset($_GET['brand'])): ?> <?php echo e('&brand='.$strBrand); ?> <?php endif; ?> <?php if(isset($_GET['price'])): ?> <?php echo e('&price='.$_GET['price']); ?> <?php endif; ?>">
                                <span>Previous</span>
                            </a>
                        </li>
                        <?php
                            if($page > 5){
                                    $checkNumberPage = ceil($page / 5);
                                    $endPage = $checkNumberPage * 5;
                                    $startPage = $endPage - 4;
                                    $number = $startPage;
                                    if($totalPage < $endPage){
                                        $max = $totalPage;
                                    }else{
                                        $max = $endPage;    
                                    }
                                
                            }else{
                                $number = 1;
                                $max = 5; 
                                if($max > $totalPage){
                                    $max = $totalPage;
                                }
                            }
                        ?>
                         <?php for($i = $number;$i <= $max;$i++): ?>
                            
                         <li class="page-item <?php if($page==$i): ?> active <?php endif; ?>">
                            <a class="page-link" href="/shop?page=<?php echo e($i); ?> <?php if(isset($_GET['categories'])): ?> <?php echo e('&categories='.$_GET['categories']); ?> <?php endif; ?> <?php if(isset($_GET['brand'])): ?> <?php echo e('&brand='.$strBrand); ?> <?php endif; ?> <?php if(isset($_GET['price'])): ?> <?php echo e('&price='.$_GET['price']); ?> <?php endif; ?>"><?php echo e($i); ?>

                            </a>
                        </li>

                         <?php endfor; ?>
                        <li class="page-item  <?php if($page >= $totalPage): ?> disabled <?php endif; ?>">
                            <a class="page-link" href="'/shop?page=<?php echo e(($page+1)); ?> <?php if(isset($_GET['categories'])): ?> <?php echo e('&categories='.$_GET['categories']); ?> <?php endif; ?> <?php if(isset($_GET['brand'])): ?> <?php echo e('&brand='.$strBrand); ?> <?php endif; ?> <?php if(isset($_GET['price'])): ?> <?php echo e('&price='.$_GET['price']); ?> <?php endif; ?>">
                                Next
                            </a>
                        </li>
                      </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Shop Product End -->
    </div>
</div>
<!-- Shop End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\uas\phoneCell\resources\views/shop/index.blade.php ENDPATH**/ ?>