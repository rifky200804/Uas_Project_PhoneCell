

<?php $__env->startSection('title',config('app.name')." | Checkout"); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pb-5">
        <div class="row px-xl-5">
            <div class="col">
                <div class="bg-light p-30">
                    <div class="nav nav-tabs mb-4">
                        <a class="nav-item nav-link text-dark active" data-toggle="tab" href="#tab-pane-1">Waiting for payment</a>
                        <a class="nav-item nav-link text-dark" data-toggle="tab" href="#tab-pane-2">Packed</a>
                        <a class="nav-item nav-link text-dark" data-toggle="tab" href="#tab-pane-3">in Delivery</a>
                        <a class="nav-item nav-link text-dark" data-toggle="tab" href="#tab-pane-4">Finished</a>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="tab-pane-1">
                            <h4 class="mb-3">Waiting for payment</h4>
                            <?php $__currentLoopData = $processCodeWaiting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <table class="table table-light table-borderless table-hover text-center mb-4">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Products</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Shipping</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody class="align-middle">
                                    <?php $quantity = 0 ?>
                                    <?php foreach($waiting as $waitingItem => $value) : ?>
                                    <?php if($item->processCode == $value->processCode): ?>
                                    <tr>
                                        <td class="align-middle"><img src="<?php echo e(asset('layouts/img/product-1.jpg')); ?>" alt="" style="width: 50px;"><?php echo e($value->name_product); ?></td>
                                        <td class="align-middle">Rp. <?php echo e(number_format($value->price,2,',','.')); ?></td>
                                        <td class="align-middle"><?php echo e($value->quantity); ?></td>
                                        <td class="align-middle">Rp. <?php echo e(number_format((($value->quantity * 30000)),2,',','.')); ?></td>
                                        <td class="align-middle"><?php echo e(number_format(($value->price * $value->quantity + ($value->quantity * 30000)),2,',','.')); ?></td>
                                    </tr>
                                    <?php $quantity += $value->quantity ?>
                                    <?php endif; ?>
                                    <?php endforeach; ?>
                                </tbody>
                            

                                <tfoot class="">
                                    <tr>
                                        <th colspan="">Total</th>
                                        <th></th>
                                        <th><?php echo e($quantity); ?></th>
                                        <th>Rp. <?php echo e(number_format($item->shipping,2,',','.')); ?></th>
                                        <th>Rp. <?php echo e(number_format(($item->subTotal + $item->shipping),2,',','.')); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                            <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-2">
                            <h4 class="mb-3">Packed</h4>
                            <?php $__currentLoopData = $processCodePacked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <table class="table table-light table-borderless table-hover text-center mb-4">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Products</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Shipping</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody class="align-middle">
                                    <?php $quantity = 0 ?>
                                    <?php foreach($packed as $packedItem => $value) : ?>
                                    <?php if($item->processCode == $value->processCode): ?>
                                    <tr>
                                        <td class="align-middle"><img src="<?php echo e(asset('layouts/img/product-1.jpg')); ?>" alt="" style="width: 50px;"><?php echo e($value->name_product); ?></td>
                                        <td class="align-middle">Rp. <?php echo e(number_format($value->price,2,',','.')); ?></td>
                                        <td class="align-middle"><?php echo e($value->quantity); ?></td>
                                        <td class="align-middle">Rp. <?php echo e(number_format((($value->quantity * 30000)),2,',','.')); ?></td>
                                        <td class="align-middle"><?php echo e(number_format(($value->price * $value->quantity + ($value->quantity * 30000)),2,',','.')); ?></td>
                                    </tr>
                                    <?php $quantity += $value->quantity ?>
                                    <?php endif; ?>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot class="">
                                    <tr>
                                        <th colspan="">Total</th>
                                        <th></th>
                                        <th><?php echo e($quantity); ?></th>
                                        <th>Rp. <?php echo e(number_format($item->subTotal,2,',','.')); ?></th>
                                        <th>Rp. <?php echo e(number_format(($item->subTotal + $item->shipping),2,',','.')); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                            <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-3">
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 class="mb-3">In Delivery</h4>
                                    <?php $__currentLoopData = $processCodeDelivery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <table class="table table-light table-borderless table-hover text-center mb-4">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th>Products</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Shipping</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody class="align-middle">
                                            <?php $quantity = 0 ?>
                                            <?php foreach($delivery as $deliveryItem => $value) : ?>
                                            <tr>
                                                <td class="align-middle"><img src="<?php echo e(asset('layouts/img/product-1.jpg')); ?>" alt="" style="width: 50px;"><?php echo e($value->name_product); ?></td>
                                                <td class="align-middle">Rp. <?php echo e(number_format($value->price,2,',','.')); ?></td>
                                                <td class="align-middle"><?php echo e($value->quantity); ?></td>
                                                <td class="align-middle">Rp. <?php echo e(number_format((($value->quantity * 30000)),2,',','.')); ?></td>
                                                <td class="align-middle"><?php echo e(number_format(($value->price * $value->quantity + ($value->quantity * 30000)),2,',','.')); ?></td>
                                            </tr>
                                            <?php $quantity += $value->quantity ?>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot class="">
                                            <tr>
                                                <th colspan="">Total</th>
                                                <th></th>
                                                <th><?php echo e($quantity); ?></th>
                                                <th>Rp. <?php echo e(number_format($item->shipping,2,',','.')); ?></th>
                                                <th>Rp. <?php echo e(number_format(($item->subTotal + $item->shipping),2,',','.')); ?></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-4">
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 class="mb-4">Finished</h4>
                                    <?php $__currentLoopData = $processCodeFinished; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <table class="table table-light table-borderless table-hover text-center mb-4">
                                        <thead class="thead-dark">
                                            <tr>
                                                <th>Products</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Shipping</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody class="align-middle">
                                            <?php $quantity = 0 ?>
                                            <?php foreach($finished as $finishedItem => $value) : ?>
                                            <tr>
                                                <td class="align-middle"><img src="<?php echo e(asset('layouts/img/product-1.jpg')); ?>" alt="" style="width: 50px;"><?php echo e($value->name_product); ?></td>
                                                <td class="align-middle">Rp. <?php echo e(number_format($value->price,2,',','.')); ?></td>
                                                <td class="align-middle"><?php echo e($value->quantity); ?></td>
                                                <td class="align-middle">Rp. <?php echo e(number_format((($value->quantity * 30000)),2,',','.')); ?></td>
                                                <td class="align-middle"><?php echo e(number_format(($value->price * $value->quantity + ($value->quantity * 30000)),2,',','.')); ?></td>
                                            </tr>
                                            <?php $quantity += $value->quantity ?>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot class="">
                                            <tr>
                                                <th colspan="">Total</th>
                                                <th></th>
                                                <th><?php echo e($quantity); ?></th>
                                                <th>Rp. <?php echo e(number_format($item->shipping,2,',','.')); ?></th>
                                                <th>Rp. <?php echo e(number_format(($item->subTotal + $item->shipping),2,',','.')); ?></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <hr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\uas\phoneCell\resources\views/shop/order.blade.php ENDPATH**/ ?>