<?php $__env->startSection('tilte',config('app.name')." | My Profile"); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row px-xl-5">
        <div class="col-12">
            <nav class="breadcrumb bg-light mb-30">
                <a class="breadcrumb-item text-dark" href="<?php echo e(route('welcome')); ?>">Home</a>
                <span class="breadcrumb-item active">My Profile</span>
            </nav>
        </div>
    </div>
</div>

<div class="container-fluid">
    <h2 class="section-title position-relative text-uppercase mx-xl-5 mb-4"><span class="bg-secondary pr-3">My Profile</span></h2>
    <div class="row px-xl-5">
        <div class="col-lg-12 mb-5">
            <div class="contact-form bg-light p-30">
                <div id="success"></div>
                <form action="<?php echo e(route('myProfile.update',$data->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="control-group">
                        <input type="text" class="form-control" name="full_name" id="full_name" placeholder="Your full_name" required="required" data-validation-required-message="Please enter your Full Name" value="<?php echo e($data->full_name); ?>">
                        <p class="help-block text-danger"></p>
                    </div>
                    <div class="control-group">
                        <input type="email" class="form-control" id="email" placeholder="Your Email" required="required" data-validation-required-message="Please enter your email" value="<?php echo e($data->email); ?>" disabled>
                        <input type="hidden" name="email" value="<?php echo e($data->email); ?>">
                        <p class="help-block text-danger"></p>
                    </div>
                    <div class="control-group">
                        <input type="text" class="form-control" name="place_of_birth" id="subject" placeholder="Place Of Birth" required="required" data-validation-required-message="Please enter a subject" aria-invalid="false" value="<?php echo e($data->place_of_birth); ?>">
                        <p class="help-block text-danger"></p>
                    </div>
                    <div class="control-group">
                        <input type="date" class="form-control" name="date_of_birth" id="subject" required="required" data-validation-required-message="Please enter a subject" aria-invalid="false" value="<?php echo e($data->date_of_birth); ?>">
                        <p class="help-block text-danger"></p>
                    </div>
                    <div class="control-group">
                        <textarea class="form-control" rows="8" name="address" id="address" placeholder="Your Address" required="required" data-validation-required-message="Please enter your Address"><?php echo e($data->address); ?></textarea>
                        <p class="help-block text-danger"></p>
                    </div>
                    
                    <div>
                        <button class="btn btn-primary py-2 px-4" type="submit" id="sendMessageButton">Update Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\uas\phoneCell\resources\views/myProfile.blade.php ENDPATH**/ ?>